﻿namespace DashboardFrontEnd
{
    partial class LandingPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.KPIbutton = new System.Windows.Forms.Button();
            this.PLbutton = new System.Windows.Forms.Button();
            this.safetybutton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1365, 137);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(190)))), ((int)(((byte)(192)))));
            this.panel2.Controls.Add(this.safetybutton);
            this.panel2.Controls.Add(this.PLbutton);
            this.panel2.Controls.Add(this.KPIbutton);
            this.panel2.Location = new System.Drawing.Point(0, 101);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1362, 499);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DashboardFrontEnd.Properties.Resources.Logo_HunteysClubhouse;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(410, 137);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // KPIbutton
            // 
            this.KPIbutton.BackColor = System.Drawing.Color.LightSkyBlue;
            this.KPIbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KPIbutton.Location = new System.Drawing.Point(100, 69);
            this.KPIbutton.Name = "KPIbutton";
            this.KPIbutton.Size = new System.Drawing.Size(190, 152);
            this.KPIbutton.TabIndex = 0;
            this.KPIbutton.Text = "KPIs";
            this.KPIbutton.UseVisualStyleBackColor = false;
            this.KPIbutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // PLbutton
            // 
            this.PLbutton.BackColor = System.Drawing.Color.LightSkyBlue;
            this.PLbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLbutton.Location = new System.Drawing.Point(564, 69);
            this.PLbutton.Name = "PLbutton";
            this.PLbutton.Size = new System.Drawing.Size(190, 152);
            this.PLbutton.TabIndex = 1;
            this.PLbutton.Text = "Profitability & Loss per center & room";
            this.PLbutton.UseVisualStyleBackColor = false;
            this.PLbutton.Click += new System.EventHandler(this.PLbutton_Click);
            // 
            // safetybutton
            // 
            this.safetybutton.BackColor = System.Drawing.Color.LightSkyBlue;
            this.safetybutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.safetybutton.Location = new System.Drawing.Point(1025, 75);
            this.safetybutton.Name = "safetybutton";
            this.safetybutton.Size = new System.Drawing.Size(190, 152);
            this.safetybutton.TabIndex = 2;
            this.safetybutton.Text = "Safety Tracking";
            this.safetybutton.UseVisualStyleBackColor = false;
            this.safetybutton.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // LandingPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1363, 597);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "LandingPage";
            this.Text = "Form2";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button KPIbutton;
        private System.Windows.Forms.Button PLbutton;
        private System.Windows.Forms.Button safetybutton;
    }
}